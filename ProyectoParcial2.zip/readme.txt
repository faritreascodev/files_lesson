Objetivo Principal:
-Diseñar un programa funcional para resolver la problemática descrita en el archivo .pdf, con una interfaz inicial por consola que sea intuitiva y fácil de usar.

****Desafío Opcional:
-Implementar una interfaz gráfica con Swing y JPanel para hacer la aplicación más visual y amigable, incorporando botones, campos de texto y otros elementos interactivos.

El programa debe ser funcional y garantizar una buena experiencia para el usuario en ambas versiones.

nota: Documentar cada proceso que se haga con respecto a los 4 pilares de la programación orientada a objetos
